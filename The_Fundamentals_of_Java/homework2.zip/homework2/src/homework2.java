// File Name: Homework2
//  We thought of attributes that I could use to describe this song entitled
// "One Day" by Matisyahu and saved each attribute into variables of different
// data types.
// Created by: [Anthony Heitzeberg]
public class homework2 {
    public static void main(String[] args) {
        String song_title = "One Day"; // name of song
        String artist = "Matisyahu"; // name of artist
        String featured_artist = "Akon"; // name of featured artist
        String album_name = "Light"; // album name
        String genre = "Reggae"; // genre of the song
        int year = 2008; // year is was released
        String record_label = "Epic"; // name of record label
        float views_by_millions = 75.46f; // float to hold the views on yt vid by millions
        double week_sales_by_thousands = 16.453;

        System.out.println(song_title);
        System.out.println(artist);
        System.out.println(featured_artist);
        System.out.println(album_name);
        System.out.println(genre);
        System.out.println(year);
        System.out.println(record_label);
        System.out.println(views_by_millions);
        System.out.println(week_sales_by_thousands);
    }
}
