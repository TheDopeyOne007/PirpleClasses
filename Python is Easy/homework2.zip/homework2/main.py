song_title = "One Day" # name of song
Artist = "Matisyahu" # name of artist
featured_artist = "Akon" # name of featured artist
album_name = "Light" # album name
Genre = "Reggae" # genre of the song
Year = 2008 # year is was released
record_label = "Epic" # name of record label 
views_by_millions = 75.46 # float to hold the views on yt vid by millions
IsMale = True

"""
I just added this for the extra credit, but yeah below will print all the info of the song
and this whole block will be ignored
"""

def artist():
    return Artist

def year():
    return Year

def genre():
    return Genre

def isMale():
    return IsMale


artist_var = artist()
year_var = year()
genre_var = genre()
isMale_var = isMale()

print(artist_var, year_var, genre_var, isMale_var)

# Print statements for homework1
# print(song_title)
# print(artist)
# print(featured_artist)
# print(album_name)
# print(genre)
# print(year)
# print(record_label)
# print(views_by_millions)

