from os import truncate


def checkEquality(a, b, c):
    a = int(a)
    b = int(b)
    c = int(c)
    equals = 0
    if a == b or b == c or a == c:
        return True
    return False


print(checkEquality(8, 6, 7))