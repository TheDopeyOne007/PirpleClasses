song_title = "One Day" # name of song
artist = "Matisyahu" # name of artist
featured_artist = "Akon" # name of featured artist
album_name = "Light" # album name
genre = "Reggae" # genre of the song
year = 2008 # year is was released
record_label = "Epic" # name of record label 
views_by_millions = 75.46 # float to hold the views on yt vid by millions

"""
I just added this for the extra credit, but yeah below will print all the info of the song
and this whole block will be ignored
"""

print(song_title)
print(artist)
print(featured_artist)
print(album_name)
print(genre)
print(year)
print(record_label)
print(views_by_millions)

