// Dear Instructor,
// I unfortunately can't use Code Blocks, since it is not supported on Mac anymore,
// however I have used it before when I was in the computer laboratory in my school.
// But I really hope it's okay if I can use XCode or Clion since both are already downloaded and
// set up on my Macbook. Thank you so much and really enjoying the class so far.
#include <iostream>
using namespace std;
int main(int argc, const char * argv[]) {
    int greenBottles = 10;
    cout << "There were " << greenBottles << " bottles" << endl;
    greenBottles--;
    cout << "There were " << greenBottles << " bottles" << endl;
    return 0;
}
