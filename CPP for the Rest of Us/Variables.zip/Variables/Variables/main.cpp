#include <iostream>

using namespace std;

int main(int argc, const char * argv[]) {
    const int MINUTES_PER_HOUR = 60;
    // const are read-only and can't be changed once declared
//    MINUTES_PER_HOUR++;
    int numHours = 14;
    numHours++; // now numHours equals to 15
    cout << "There are " << MINUTES_PER_HOUR * numHours << " minutes in "
    << numHours << " hours" << endl; // 15 * 60 equals to 900 minutes
    unsigned int zeroHour = 0;
    zeroHour--;
    cout << "1 hour before the zero hour is " << zeroHour << endl;
    return 0;
}
