#include <iostream>

using namespace std;

int main(int argc, const char * argv[]) {
    cout << "Think of a number between 1 and 100" << endl;
    int highest = 100, lowest = 0, attempts = 0, guess = 0;
    char input; // I added this for the choices later on
    while(true) {
        guess = lowest + ((highest - lowest) * 0.5);
        attempts++;
        cout << "I guess " << guess << ". Am I right?" << endl;
        cout << "'q' to quit, 'y' if correct, 'h' if too high, 'l' if too low" << endl;
        cin >> input;
        if(input == 'q') {
            cout << "You quit. Bye." << endl;
            break;
        } else if(input == 'y') {
            cout << "I guessed it in " << attempts << " attempts." << endl;
            break;
        } else if(input == 'h') {
            highest = guess;
        } else if(input == 'l') {
            lowest = guess;
        } else {
            cout << "I didn't understand the response!" << endl;
            attempts--;
        }
    }
}
