#include <iostream>
#include <iomanip>


using namespace std;

int main(int argc, const char * argv[]) {
    // To get higher accuracy with decimals, for me, I think a double would be better
    double price1, price2, price3, total;
    
    cout << "Enter a price: ";
    cin >> price1;
    cout << "Enter a price: ";
    cin >> price2;
    cout << "Enter a price: ";
    cin >> price3;
    
    cout << endl;
    
    total = price1 + price2 + price3;
    cout << setiosflags(ios::fixed);
    cout << setprecision(2);
    cout << setw(13) << "Price 1 is " << setw(9) << price1 << endl;
    cout << setw(13) << "Price 2 is " << setw(9) << price2 << endl;
    cout << setw(13) << "Price 3 is " << setw(9) << price3 << endl;
    cout << setw(13) << "Total price: " << setw(9) << total << endl;
    return 0;
}
