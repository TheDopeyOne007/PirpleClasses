#include <iostream>
#include <string>
#include <bitset>

using namespace std;

int rotateLeft (int value, int amount)
{
    //four bit rotate left
    const int OVERFLOW = 0b10000;
        while (amount > 0)
        {
            value = value << 1;
            if (((value & OVERFLOW) == OVERFLOW))
            {
                value = value & 0b1111;  //remove overflow bit
                value = value | 0b0001;  //set the rightmost bit
            }
            amount--;
        }
    return value;
}

int main(int argc, const char * argv[]) {
    int inValvesOpen = 0b0010, outValvesOpen = 0b0100, pistonUp = 0b1010, cylinderFire = 0b1000;
    for(int i = 0; i < 5; i++) {
        int currentFire = 0;
        int bitsToRotate = 0;
        
        string d1 = "     1        2        3        4    ";
        string d2 = "    ___      ___      ___      ___   ";
        string d3 = "  x|   |x  x|   |x  x|   |x  x|   |x ";
        string d4 = "   |   |    |   |    |   |    |   |  ";
        string d5 = "    ---      ---      ---      ---   ";
        string d6 = "     ?        ?        ?        ?    ";
        
        for(int c = 0; c < 5; c++) {
            char stateLabel = 'C', inValve = 'x', outValve = 'x', upPiston = ' ',
            downPiston = 'T', chamber = ' ';
            int positionMask = 0b1000;
            positionMask = positionMask >> (c % 4);
            // This offset will wrap each containers in a 9 character wide length,
            // and if you want to add the same character to another cylinder, I mod by 4
            // as a way to divide the whole length of the string into 4 parts for each cylinder
            int offset = (c % 4) * 9;
            
            if((positionMask & inValvesOpen) != 0) {
                inValve = 'o';
                stateLabel = 'I';
            }
            
            if((positionMask & pistonUp) != 0) {
                upPiston = 'T';
                downPiston = ' ';
                if((positionMask & cylinderFire) != 0) {
                    chamber = '*';
                    stateLabel = 'P';
                    currentFire = positionMask;
                }
            } else {
                chamber = ' ';
                upPiston = chamber;
                downPiston = 'T';
            }
            
            if((positionMask & outValvesOpen) != 0) {
                outValve = 'o';
                stateLabel = 'E';
            }
            
            // This will replace the characters in the string at certain parts of
            // the string by adding an offset to the indices in the first cylinder
            d3.replace(2 + offset, 1, string(1, inValve));
            d3.replace(4 + offset, 1, string(1, chamber));
            d3.replace(5 + offset, 1, string(1, upPiston));
            d3.replace(6 + offset, 1, string(1, chamber));
            d3.replace(8 + offset, 1, string(1, outValve));
            d4.replace(5 + offset, 1, string(1, downPiston));
            d6.replace(5 + offset, 1, string(1, stateLabel));
            
            // Used this to debug the answers:
//            cout << "stateLabel: " << stateLabel << endl;
//            cout << "upPiston: " << upPiston << endl;
//            cout << "downPiston: " << downPiston << endl;
//            cout << "chamber: " << chamber << endl;
//            cout << "inValve: " << inValve << endl;
//            cout << "outValve: " << outValve << endl;
//            cout << "\n";
        }
        
        // Checks if the current cylinder that will fire is at cylinder 1 and 2, then
        // bits to rotate is 2, if at cylinder 3, then bits to rotate is 1 and finally if at
        // cylinder 4 then bits to rotate is 3
        if(currentFire == 0b1000 || currentFire == 0b0100) {
            bitsToRotate = 2;
        } else if(currentFire == 0b0010) {
            bitsToRotate = 1;
        } else if(currentFire == 0b0001) {
            bitsToRotate = 3;
        }
        
        inValvesOpen = rotateLeft(inValvesOpen, bitsToRotate);
        outValvesOpen = rotateLeft(outValvesOpen, bitsToRotate);
        pistonUp = rotateLeft(pistonUp, bitsToRotate);
        cylinderFire = rotateLeft(cylinderFire, bitsToRotate);
        
        cout << "\n\n";
        cout << d1 << endl;
        cout << d2 << endl;
        cout << d3 << endl;
        cout << d4 << endl;
        cout << d5 << endl;
        cout << d6 << endl;
    }
    return 0;
}
