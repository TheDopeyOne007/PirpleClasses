#include <iostream>
#include <iomanip>

using namespace std;

bool draw = false, winner = false;
const char PLAYER_X = 'X', PLAYER_O = 'O';
char lastplayer = PLAYER_O, currentPlayer = PLAYER_X;
char board[3][3] = {
    {'1', '2', '3'},
    {'4', '5', '6'},
    {'7', '8', '9'}
};

void displayBoard() {
    cout << "Current Board State:\n";
    for(int x = 0; x < 3; x++) {
        for(int y = 0; y < 3; y++) {
            cout << "\t" << board[x][y];
            if(y != 2) {
                cout << " |";
            }
        }
        if(x != 2) {
            cout << "\n\t--+---+--" << endl;
        }
    }
}

bool checkForEndGame(int turn, char currentPlayer) {
    bool retVal = false;
    
    if(board[0][0] == board[0][1] && board[0][0] == board[0][2] && board[0][0] == currentPlayer) {
        cout << "\nPlayer " << currentPlayer << " wins at top row!\n";
        winner = true;
    }
    
    if(board[1][0] == board[1][1] && board[1][0] == board[1][2] && board[1][0] == currentPlayer) {
        cout << "\nPlayer " << currentPlayer << " wins at middle row!\n";
        winner = true;
    }
    
    if(board[2][0] == board[2][1] && board[2][0] == board[2][2] && board[2][0] == currentPlayer) {
        cout << "\nPlayer " << currentPlayer << " wins at bottom row!\n";
        winner = true;
    }
    
    if(board[0][0] == board[1][1] && board[0][0] == board[2][2] && board[0][0] == currentPlayer) {
        cout << "\nPlayer " << currentPlayer << " wins at downward diagonal!\n";
        winner = true;
    }
    
    if(board[0][2] == board[1][1] && board[0][2] == board[2][0] && board[0][2] == currentPlayer) {
        cout << "\nPlayer " << currentPlayer << " wins at upward diagonal!\n";
        winner = true;
    }
    
    if(board[0][0] == board[1][0] && board[0][0] == board[2][0] && board[0][0] == currentPlayer) {
        cout << "\nPlayer " << currentPlayer << " wins at first coloumn!\n";
        winner = true;
    }
    
    if(board[0][1] == board[1][1] && board[0][1] == board[2][1] && board[0][1] == currentPlayer) {
        cout << "\nPlayer " << currentPlayer << " wins at second column!\n";
        winner = true;
    }
    
    if(board[0][2] == board[1][2] && board[0][2] == board[2][2] && board[0][2] == currentPlayer) {
        cout << "\nPlayer " << currentPlayer << " wins at third column!\n";
        winner = true;
    }
    
    else if (board[0][0] != '1' && board[0][1] != '2' && board[0][2] != '3'
      && board[1][0] != '4' && board[1][1] != '5' && board[1][2] != '6'
             && board[2][0] != '7' && board[2][1] != '8' && board[2][2] != '9') {
        cout << "\nIt's a draw!\n";
        draw = true;
    }
    
    // If at turn 8 which is the 9th turn and there is still no winner, its a draw and should be game over
    if(turn == 8) {
        retVal = true;
        return retVal;
    }
    
    // check if there is a draw or winner, if any are true the game should be over
    retVal = (winner || draw);
    return retVal;
}

void getPlayerChoice(char currentPlayer) {
    int chosenSquare = 0;
    bool inputValid = false;
    while (inputValid == false) {
        cout << "\n\n";
        cout << "Player " << currentPlayer << ", enter a number between 1 and 9: ";
        cin >> chosenSquare;
        if(chosenSquare < 1 || chosenSquare > 9) {
            cout << "Not a valid choice. Try again.\n";
            continue;
        } else {
            chosenSquare--;
        }
        
        if(board[chosenSquare/3][chosenSquare%3] == currentPlayer || board[chosenSquare/3][chosenSquare%3] == lastplayer) {
            cout << "Not a valid choice. Try again.";
            continue;
        } else {
            board[chosenSquare/3][chosenSquare%3] = currentPlayer;
            inputValid = true;
        }
    }
}

int main(int argc, const char * argv[]) {
    bool isGameOver = false;
    int turn = 0;
    
    cout << "TIC-TAC-TOE" << endl;
    cout << "Player 1-X Player 2-0\n" << endl;
    displayBoard();
    
    while(winner == false && draw == false) {
        getPlayerChoice(currentPlayer);
        displayBoard();
        cout << endl;
        turn += 1;
        isGameOver = checkForEndGame(turn, currentPlayer);
        swap(currentPlayer, lastplayer);
    }
    return 0;
}

