#include <iostream>
#include <string>

using namespace std;

const string by = " by ";
const string hyphen = "-";
const string colon = ":";

string trim(string s) {
    string retVal = s;
    unsigned int lastPos = retVal.length() - 1;
    bool found = true;
    while(found == true && lastPos >= 0) {
        if(retVal.substr(lastPos, 1) == " ") {
            retVal = retVal.erase(lastPos, 1);
        } else if(retVal.substr(0, 1) == " ") {
            retVal = retVal.erase(0, 1);
        } else {
            found = false;
        }
        lastPos = retVal.length() - 1;
    }
    return retVal;
}

int main(int argc, const char * argv[]) {
    while(true) {
        string song;
        string artist;
        string title;
        int position = 0;
        cout << "Enter a track of 'Q' to quit: ";
        getline(cin, song);

        if(song == "Q" or song == "q") {
            cout << "Closing program\n";
            break;
        }

        if(song.length() < 5) {
            cout << "please enter a track with more than five characters\n";
            continue;
        }
        if(song.find(colon) != -1) {
            position = song.find(colon);
            artist = song.substr(0, position+1);
            title = song.substr(position, song.length() - position);
        } else if(song.find(hyphen) != -1) {
            position = song.find(hyphen);
            artist = song.substr(position+1, song.length() - position);
            title = song.substr(0, position);
        } else if(song.find(by) != -1) {
            position = song.find(by);
            artist = song.substr(position + by.length(), song.length() - position);
            title = song.substr(0, position);
        } else {
            cout << "Unable to identify artist and title" << endl;
            continue;
        }
        
        cout << "TITLE: " << trim(title) << endl;
        cout << "ARTIST: " << trim(artist) << endl;
    }
    return 0;
}
